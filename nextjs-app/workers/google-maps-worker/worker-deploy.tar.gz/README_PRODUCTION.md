# Customer Import Worker - Production Setup

## Architektur

```
┌─────────────────────┐                    ┌──────────────────────┐
│  Vercel (Next.js)   │                    │  Ihr Server          │
│  app.aplus-...de    │                    │  worker.aplus-...de  │
│                     │  HTTP POST         │                      │
│  POST /api/...      │ ────────────────>  │  FastAPI Server      │
│  /customer-import   │  /process-job      │  Port 8000           │
│  /jobs              │                    │                      │
└─────────────────────┘                    └──────────────────────┘
         │                                           │
         │                                           │
         │         MongoDB Atlas (Cloud)             │
         │       geruestbau_erp Database             │
         └─────────────────┬─────────────────────────┘
                           │
                  Jobs & Results Collection

```

## Schnellstart (5 Schritte)

### 1. Server vorbereiten

```bash
# SSH auf Server
ssh user@your-server-ip

# Arbeitsverzeichnis erstellen
sudo mkdir -p /opt/customer-import-worker
sudo chown $USER:$USER /opt/customer-import-worker
cd /opt/customer-import-worker
```

### 2. Dateien auf Server kopieren

**Auf Ihrem lokalen Mac:**
```bash
cd /Users/tolgahanvardar/Desktop/Geruestbau-ERP/nextjs-app/workers/google-maps-worker

# Alle Dateien auf Server kopieren
scp -r \
  api.py \
  worker.py \
  website_analyzer.py \
  requirements.txt \
  Dockerfile \
  docker-compose.yml \
  .dockerignore \
  user@your-server-ip:/opt/customer-import-worker/
```

### 3. Environment Variables setzen

**Auf dem Server:**
```bash
cd /opt/customer-import-worker

# .env Datei erstellen
cat > .env << 'EOF'
# MongoDB Connection (WICHTIG: Gleiche URI wie in Vercel!)
MONGODB_URI=mongodb://GeruestbauAPLUS_db_user:spUVToPfcNNrGaEb@ac-o0nij6p-shard-00-01.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-02.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-00.0vn5roj.mongodb.net:27017/geruestbau_erp?ssl=true&authSource=admin&retryWrites=true&w=majority
MONGODB_DB=geruestbau_erp

# Google Maps API Key
GOOGLE_MAPS_API_KEY=AIzaSyA_1c2x50fbRkDFoOblzZS1vWMhxfB7hRQ

# Server Config
PORT=8000
ENVIRONMENT=production
EOF

# Rechte setzen
chmod 600 .env
```

### 4. Docker starten

```bash
# Docker Container bauen und starten
docker-compose up -d --build

# Status prüfen (sollte "Up" zeigen)
docker-compose ps

# Logs anschauen
docker-compose logs -f worker-api
```

Erwartete Log-Ausgabe:
```
========================================
🚀 Customer Import Worker API
========================================
Port: 8000
Environment: production
MongoDB: ✓
Google Maps: ✓
========================================
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### 5. Vercel Environment Variable setzen

**Option A: Via CLI**
```bash
cd /Users/tolgahanvardar/Desktop/Geruestbau-ERP/nextjs-app

# Setze Worker URL (ersetze mit Ihrer Domain/IP)
echo "https://worker.aplus-geruestbau.de" | vercel env add WORKER_API_URL production
echo "https://worker.aplus-geruestbau.de" | vercel env add WORKER_API_URL preview  
echo "https://worker.aplus-geruestbau.de" | vercel env add WORKER_API_URL development
```

**Option B: Via Vercel Dashboard**
1. https://vercel.com → Projekt öffnen
2. Settings → Environment Variables
3. Add Variable:
   - Name: `WORKER_API_URL`
   - Value: `https://worker.aplus-geruestbau.de` (oder `http://YOUR-SERVER-IP:8000`)
   - Environments: Production, Preview, Development

## Testing

### 1. Health Check

```bash
# Auf dem Server:
curl http://localhost:8000/health

# Von außen (nach Nginx Setup):
curl https://worker.aplus-geruestbau.de/health
```

Erwartete Antwort:
```json
{
  "status": "healthy",
  "timestamp": "2026-01-01T20:00:00.000000",
  "version": "1.0.0",
  "mongodb_connected": true,
  "google_maps_configured": true
}
```

### 2. Kompletter Test-Flow

```bash
# Test Job erstellen (direkt via Worker API)
curl -X POST http://localhost:8000/process-job \
  -H "Content-Type: application/json" \
  -d '{
    "jobId": "test123",
    "mongoUri": "mongodb://...",
    "googleMapsApiKey": "AIza..."
  }'
```

### 3. In Production testen

1. Vercel deployen: `vercel deploy --prod`
2. In App einloggen: https://app.aplus-geruestbau.de
3. Kunden → Neuer Kunde → KI Kunden hinzufügen
4. Analyse starten
5. Worker-Logs beobachten:
   ```bash
   docker-compose logs -f worker-api
   ```

## Nginx Reverse Proxy (empfohlen)

Für HTTPS und bessere Sicherheit:

```bash
# Nginx installieren
sudo apt install nginx certbot python3-certbot-nginx

# Config erstellen
sudo nano /etc/nginx/sites-available/worker
```

Inhalt:
```nginx
server {
    listen 80;
    server_name worker.aplus-geruestbau.de;

    location / {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Wichtig für lange API-Calls!
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
    }
}
```

```bash
# Aktivieren
sudo ln -s /etc/nginx/sites-available/worker /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# SSL Zertifikat
sudo certbot --nginx -d worker.aplus-geruestbau.de
```

## Monitoring & Wartung

### Container Status

```bash
# Status prüfen
docker-compose ps

# Logs live
docker-compose logs -f

# Ressourcen
docker stats

# Neustart
docker-compose restart
```

### Updates deployen

```bash
cd /opt/customer-import-worker

# Code aktualisieren (z.B. via SCP oder Git)
scp api.py user@server:/opt/customer-import-worker/

# Container neu bauen
docker-compose up -d --build

# Alte Images aufräumen
docker image prune -f
```

### Troubleshooting

**Container startet nicht:**
```bash
docker-compose logs worker-api
docker-compose restart worker-api
```

**MongoDB Connection Error:**
```bash
# Teste Verbindung
docker-compose exec worker-api python -c "from pymongo import MongoClient; print(MongoClient('$MONGODB_URI').server_info())"
```

**Worker API nicht erreichbar:**
```bash
# Prüfe ob Port offen ist
sudo netstat -tulpn | grep 8000

# Prüfe Firewall
sudo ufw status
sudo ufw allow 8000/tcp
```

## Sicherheit

### Firewall konfigurieren

```bash
# Nur Nginx-Ports öffnen (80, 443)
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw enable

# Port 8000 NICHT öffentlich öffnen (nur via Nginx!)
```

### API Key Rotation

Wenn Google Maps API Key geändert wird:
```bash
# .env anpassen
nano /opt/customer-import-worker/.env

# Container neu starten
docker-compose restart

# Auch in Vercel aktualisieren!
vercel env rm GOOGLE_MAPS_API_KEY production
echo "NEUER_KEY" | vercel env add GOOGLE_MAPS_API_KEY production
```

## Performance

Für mehr Performance bei vielen gleichzeitigen Jobs:

```bash
# In docker-compose.yml anpassen:
# deploy:
#   replicas: 3  # Mehrere Worker-Instanzen
```

Oder Load Balancer (Nginx) verwenden:
```nginx
upstream worker_backend {
    server localhost:8000;
    server localhost:8001;
    server localhost:8002;
}
```

## Kosten

- **Server**: Je nach Anbieter (ca. 5-20€/Monat)
- **Google Maps API**: Pay-per-use (erste $200/Monat gratis)
- **MongoDB Atlas**: Bereits vorhanden (geteilt mit Vercel)
- **Domain/SSL**: Kostenlos mit Let's Encrypt

## Support

Bei Problemen:
1. Logs prüfen: `docker-compose logs -f`
2. Health Check: `curl http://localhost:8000/health`
3. MongoDB Connection testen
4. Vercel Logs prüfen: `vercel logs`

