# 🚀 Setup-Anleitung: KI-Import Worker auf eigenem Server

## ✅ Alle Todos erledigt!

- [x] Python Worker → FastAPI REST API
- [x] Docker + docker-compose Setup
- [x] Vercel API auf HTTP umgestellt
- [x] Git commit & push
- [x] Vercel deployed

## 📍 Wo Sie jetzt sind

- ✅ **Vercel App deployed:** https://app.aplus-geruestbau.de  
- ✅ **Code bereit:** `/workers/google-maps-worker/`
- ⏳ **Server Setup:** Noch zu erledigen

---

## 🎯 Schritt-für-Schritt Setup (15 Minuten)

### Schritt 1: Dateien auf Server kopieren (2 Min)

```bash
# Auf Ihrem Mac - Terminal öffnen
cd /Users/tolgahanvardar/Desktop/Geruestbau-ERP/nextjs-app/workers/google-maps-worker

# Ersetzen Sie USER und SERVER_IP mit Ihren Daten
scp -r \
  api.py \
  worker.py \
  website_analyzer.py \
  requirements.txt \
  Dockerfile \
  docker-compose.yml \
  .dockerignore \
  USER@SERVER_IP:/opt/customer-import-worker/
```

**Beispiel:**
```bash
scp -r api.py worker.py website_analyzer.py requirements.txt Dockerfile docker-compose.yml .dockerignore \
  root@185.123.456.789:/opt/customer-import-worker/
```

### Schritt 2: Auf Server einloggen (1 Min)

```bash
ssh USER@SERVER_IP
```

### Schritt 3: Docker installieren (falls noch nicht vorhanden) (3 Min)

```bash
# Docker installieren
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Docker Compose Plugin
sudo apt-get update
sudo apt-get install docker-compose-plugin -y

# User zu Docker-Gruppe (logout/login nötig danach)
sudo usermod -aG docker $USER

# Session neu laden
newgrp docker
```

### Schritt 4: Environment Variables setzen (2 Min)

```bash
cd /opt/customer-import-worker

# .env Datei erstellen
nano .env
```

**Inhalt (kopieren und einfügen):**
```bash
# MongoDB Connection (aus Vercel übernehmen!)
MONGODB_URI=mongodb://GeruestbauAPLUS_db_user:spUVToPfcNNrGaEb@ac-o0nij6p-shard-00-01.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-02.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-00.0vn5roj.mongodb.net:27017/geruestbau_erp?ssl=true&authSource=admin&retryWrites=true&w=majority
MONGODB_DB=geruestbau_erp

# Google Maps API Key
GOOGLE_MAPS_API_KEY=AIzaSyA_1c2x50fbRkDFoOblzZS1vWMhxfB7hRQ

# Server Config
PORT=8000
ENVIRONMENT=production
```

**Speichern:** `Ctrl+O`, `Enter`, `Ctrl+X`

### Schritt 5: Docker starten (3 Min)

```bash
cd /opt/customer-import-worker

# Container bauen und starten
docker-compose up -d --build

# Logs anschauen (sollte "Uvicorn running" zeigen)
docker-compose logs -f
```

**Erwartete Ausgabe:**
```
========================================
🚀 Customer Import Worker API
========================================
Port: 8000
Environment: production
MongoDB: ✓
Google Maps: ✓
========================================
INFO:     Uvicorn running on http://0.0.0.0:8000
```

**Logs beenden:** `Ctrl+C`

### Schritt 6: Health Check (1 Min)

```bash
# Teste ob Worker läuft
curl http://localhost:8000/health
```

**Erwartete Antwort:**
```json
{
  "status": "healthy",
  "timestamp": "2026-01-01T20:00:00",
  "version": "1.0.0",
  "mongodb_connected": true,
  "google_maps_configured": true
}
```

✅ **Wenn Sie das sehen: Worker läuft!**

### Schritt 7: Vercel Environment Variable setzen (3 Min)

**Auf Ihrem Mac:**

```bash
cd /Users/tolgahanvardar/Desktop/Geruestbau-ERP/nextjs-app

# Option A: Mit Domain (empfohlen)
echo "https://worker.aplus-geruestbau.de" | vercel env add WORKER_API_URL production

# Option B: Mit Server-IP
echo "http://YOUR-SERVER-IP:8000" | vercel env add WORKER_API_URL production

# Auch für Preview & Development
echo "http://YOUR-SERVER-IP:8000" | vercel env add WORKER_API_URL preview
echo "http://YOUR-SERVER-IP:8000" | vercel env add WORKER_API_URL development
```

**Beispiel:**
```bash
echo "http://185.123.456.789:8000" | vercel env add WORKER_API_URL production
```

### Schritt 8: Vercel redeploy (2 Min)

```bash
# Finales Deployment mit Worker-URL
vercel deploy --prod --yes
```

---

## 🧪 TESTEN!

1. **Öffnen Sie:** https://app.aplus-geruestbau.de

2. **Login** als Admin

3. **Kunden → Neuer Kunde → KI Kunden hinzufügen**

4. **Eingeben:**
   - Branche: "Dachdecker"
   - Standort: "Hamburg"
   - Anzahl: 5
   - ✅ "Webseite analysieren"

5. **"Analyse starten" klicken**

6. **Auf dem Server Logs beobachten:**
   ```bash
   docker-compose logs -f worker-api
   ```

7. **Sie sollten sehen:**
   ```
   🚀 Starting worker for job 6956c...
   Searching for: Dachdecker in Hamburg
   Found 5 results
   Analyzing website: https://example.com
   ✅ Worker completed for job 6956c...
   ```

8. **Im Browser:**
   - Nach 1-2 Minuten: Ergebnisse erscheinen
   - Kunden auswählen
   - "X Kunden importieren"
   - **✅ ES FUNKTIONIERT!**

---

## 🔒 Bonus: HTTPS mit Nginx (Optional, aber empfohlen)

### Voraussetzung: Domain/Subdomain

Erstellen Sie einen A-Record:
```
worker.aplus-geruestbau.de → YOUR-SERVER-IP
```

### Nginx installieren

```bash
sudo apt install nginx certbot python3-certbot-nginx -y
```

### Config erstellen

```bash
sudo nano /etc/nginx/sites-available/worker
```

**Inhalt:**
```nginx
server {
    listen 80;
    server_name worker.aplus-geruestbau.de;

    location / {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Lange Timeouts für API-Calls
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
    }
}
```

### Aktivieren

```bash
sudo ln -s /etc/nginx/sites-available/worker /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### SSL Zertifikat

```bash
sudo certbot --nginx -d worker.aplus-geruestbau.de
```

### Vercel ENV anpassen

```bash
# HTTPS statt HTTP!
echo "https://worker.aplus-geruestbau.de" | vercel env add WORKER_API_URL production
vercel deploy --prod --yes
```

---

## 📊 Monitoring

```bash
# Container Status
docker-compose ps

# Live Logs
docker-compose logs -f worker-api

# Ressourcen
docker stats

# Neustart
docker-compose restart

# Stoppen
docker-compose down

# Starten
docker-compose up -d
```

---

## 🐛 Troubleshooting

### "Connection refused" beim Health Check

```bash
# Prüfe ob Container läuft
docker-compose ps

# Prüfe Logs
docker-compose logs worker-api

# Neustart
docker-compose restart
```

### "MongoDB connection failed"

```bash
# Prüfe .env Datei
cat .env | grep MONGODB_URI

# Teste MongoDB Connection
docker-compose exec worker-api python -c "from pymongo import MongoClient; print(MongoClient('$(cat .env | grep MONGODB_URI | cut -d= -f2)').server_info())"
```

### Worker API von Vercel nicht erreichbar

```bash
# Prüfe Firewall
sudo ufw status
sudo ufw allow 8000/tcp

# Oder mit Nginx:
sudo ufw allow 'Nginx Full'
```

### Jobs bleiben in "queued"

```bash
# Prüfe Worker Logs
docker-compose logs -f worker-api

# Prüfe Vercel ENV
vercel env ls | grep WORKER_API_URL

# Teste Worker direkt
curl -X POST http://localhost:8000/process-job \
  -H "Content-Type: application/json" \
  -d '{"jobId":"test123","mongoUri":"...","googleMapsApiKey":"..."}'
```

---

## ✅ Success Checklist

- [ ] Docker auf Server installiert
- [ ] Dateien auf Server kopiert
- [ ] `.env` Datei erstellt
- [ ] Docker Container läuft (`docker-compose ps` → "Up")
- [ ] Health Check erfolgreich (`curl http://localhost:8000/health`)
- [ ] `WORKER_API_URL` in Vercel gesetzt
- [ ] Vercel deployed
- [ ] Test-Import durchgeführt
- [ ] Kunden erfolgreich importiert!

**Wenn alle Punkte ✅ sind: FERTIG! 🎉**

---

## 💰 Kosten-Übersicht

- **Server:** 5-20€/Monat (je nach Anbieter)
- **Domain:** ~10€/Jahr (optional)
- **SSL:** Kostenlos (Let's Encrypt)
- **MongoDB:** Bereits vorhanden
- **Google Maps API:** Erste $200/Monat gratis
- **Vercel:** Bereits vorhanden

---

## 📞 Support

Bei Problemen:
1. Logs prüfen: `docker-compose logs -f`
2. Health Check: `curl http://localhost:8000/health`
3. Vercel Logs: `vercel logs`
4. README_PRODUCTION.md für Details

**Der Worker läuft jetzt 24/7 und verarbeitet alle Import-Jobs automatisch!** 🚀

