# Deployment auf eigenem Server

## Voraussetzungen

- Linux Server (Ubuntu/Debian empfohlen)
- Docker & Docker Compose installiert
- Port 8000 offen (oder eigener Port)
- Domain/Subdomain für den Worker (z.B. `worker.aplus-geruestbau.de`)

## 1. Docker & Docker Compose installieren

```bash
# Docker installieren
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Docker Compose installieren
sudo apt-get install docker-compose-plugin

# User zu docker group hinzufügen
sudo usermod -aG docker $USER
```

## 2. Dateien auf Server kopieren

```bash
# Auf lokalem Rechner
cd /Users/tolgahanvardar/Desktop/Geruestbau-ERP/nextjs-app/workers/google-maps-worker

# Via SCP auf Server kopieren
scp -r . user@your-server-ip:/opt/customer-import-worker/
```

## 3. Environment Variables konfigurieren

Auf dem Server:

```bash
cd /opt/customer-import-worker

# .env Datei erstellen
nano .env
```

Inhalt der `.env`:
```bash
# MongoDB Connection (gleiche wie Vercel)
MONGODB_URI=mongodb://GeruestbauAPLUS_db_user:spUVToPfcNNrGaEb@ac-o0nij6p-shard-00-01.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-02.0vn5roj.mongodb.net:27017,ac-o0nij6p-shard-00-00.0vn5roj.mongodb.net:27017/geruestbau_erp?ssl=true&authSource=admin&retryWrites=true&w=majority
MONGODB_DB=geruestbau_erp

# Google Maps API Key
GOOGLE_MAPS_API_KEY=AIzaSyA_1c2x50fbRkDFoOblzZS1vWMhxfB7hRQ

# Server Config
PORT=8000
ENVIRONMENT=production
```

## 4. Docker Container starten

```bash
# Container bauen und starten
docker-compose up -d --build

# Logs anschauen
docker-compose logs -f

# Status prüfen
docker-compose ps
```

## 5. Nginx Reverse Proxy einrichten (empfohlen)

```bash
# Nginx installieren
sudo apt install nginx certbot python3-certbot-nginx

# Nginx Config erstellen
sudo nano /etc/nginx/sites-available/worker
```

Nginx Config:
```nginx
server {
    listen 80;
    server_name worker.aplus-geruestbau.de;

    location / {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts für lange API-Calls
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
        proxy_read_timeout 300;
    }
}
```

```bash
# Symlink erstellen
sudo ln -s /etc/nginx/sites-available/worker /etc/nginx/sites-enabled/

# Nginx testen und neu laden
sudo nginx -t
sudo systemctl reload nginx

# SSL Zertifikat mit Let's Encrypt
sudo certbot --nginx -d worker.aplus-geruestbau.de
```

## 6. Testen

```bash
# Health Check
curl http://worker.aplus-geruestbau.de/health

# Oder lokal:
curl http://localhost:8000/health
```

Erwartete Antwort:
```json
{
  "status": "healthy",
  "timestamp": "2026-01-01T20:00:00",
  "version": "1.0.0",
  "mongodb_connected": true,
  "google_maps_configured": true
}
```

## 7. Auto-Start bei Server-Neustart

```bash
# Docker Compose Auto-Start aktivieren
sudo systemctl enable docker

# Container wird automatisch mit restart: unless-stopped Policy starten
```

## 8. Monitoring (optional aber empfohlen)

```bash
# Container Status überwachen
docker-compose ps

# Logs live anschauen
docker-compose logs -f worker-api

# Letzte 100 Zeilen
docker-compose logs --tail=100 worker-api

# Ressourcen-Nutzung
docker stats
```

## 9. Updates deployen

```bash
cd /opt/customer-import-worker

# Neue Dateien pullen (z.B. via git)
git pull

# Container neu bauen und starten
docker-compose up -d --build

# Alte Images aufräumen
docker image prune -f
```

## Troubleshooting

### Container startet nicht
```bash
# Logs prüfen
docker-compose logs worker-api

# Container neu starten
docker-compose restart worker-api
```

### MongoDB Connection Error
```bash
# Teste MongoDB Verbindung
docker-compose exec worker-api python -c "from pymongo import MongoClient; client = MongoClient('MONGODB_URI'); print(client.server_info())"
```

### Port bereits belegt
```bash
# Prüfe welcher Prozess Port 8000 nutzt
sudo lsof -i :8000

# Anderen Port in .env setzen (z.B. 8080)
# Dann docker-compose restart
```

## Nächster Schritt

Nach erfolgreichem Deployment:
→ Vercel Environment Variable setzen:
```bash
WORKER_API_URL=https://worker.aplus-geruestbau.de
```

→ Next.js API anpassen (siehe nächster Schritt)

